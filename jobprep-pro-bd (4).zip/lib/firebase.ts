
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-storage.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCQTLSkm4t2Tksnwhqn4Ttao8_gidGW9z4",
  authDomain: "self-go-b5a5d.firebaseapp.com",
  databaseURL: "https://self-go-b5a5d-default-rtdb.firebaseio.com",
  projectId: "self-go-b5a5d",
  storageBucket: "self-go-b5a5d.appspot.com",
  messagingSenderId: "707700716819",
  appId: "1:707700716819:web:c3e0fd0a2eefa4dc1596e6"
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
export const storage = getStorage(app);
export const auth = getAuth(app);
