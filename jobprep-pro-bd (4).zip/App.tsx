
import React, { useState, useEffect } from 'react';
import { db, auth } from './lib/firebase';
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { ref, onValue, set, push } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";
import Layout from './components/Layout';
import Home from './pages/Home';
import JobSectors from './pages/JobSectors';
import PdfViewer from './components/PdfViewer';
import PremiumModal from './components/PremiumModal';
import Auth from './components/Auth';
import Exam from './pages/Exam';
import { AppState, Subject, JobCategory, AppView, PremiumConfig, SubscriptionPackage } from './types';
import { INITIAL_SUBJECTS, INITIAL_JOBS } from './constants';
import { ChevronLeft, FileText, ChevronRight, Unlock, Briefcase } from 'lucide-react';

const App: React.FC = () => {
  const [dbSubjects, setDbSubjects] = useState<Subject[]>([]);
  const [dbJobs, setDbJobs] = useState<JobCategory[]>([]);
  const [packages, setPackages] = useState<SubscriptionPackage[]>([]);
  const [premiumConfig, setPremiumConfig] = useState<PremiumConfig>({ bkashNumber: '017XXXXXXXX', monthlyPrice: 150, directAdLink: '' });
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  
  const [state, setState] = useState<AppState>(() => {
    return {
      currentView: 'HOME',
      user: null,
      tempAccessExpiry: null,
      pendingTxId: null
    };
  });

  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (user) => {
      if (user) {
        const uRef = ref(db, `users/${user.uid}`);
        onValue(uRef, (snapshot) => {
          const data = snapshot.val();
          setState(prev => ({ 
            ...prev, 
            user: data ? { ...data } : { uid: user.uid, email: user.email, isPremium: false, premiumExpiry: 0 } 
          }));
          setAuthLoading(false);
        });
      } else {
        setState(prev => ({ ...prev, user: null, currentView: 'AUTH' }));
        setAuthLoading(false);
      }
    });

    const sRef = ref(db, 'subjects');
    const jRef = ref(db, 'jobs');
    const cRef = ref(db, 'config');
    const pRef = ref(db, 'packages');

    const unsubS = onValue(sRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setDbSubjects(Object.entries(data).map(([id, val]: any) => ({ 
          ...val, 
          id, 
          chapters: val.chapters ? Object.values(val.chapters) : [] 
        })));
      }
    });

    const unsubJ = onValue(jRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setDbJobs(Object.entries(data).map(([id, val]: any) => ({ 
          ...val, 
          id,
          chapters: val.chapters ? Object.values(val.chapters) : []
        })));
      }
    });

    const unsubC = onValue(cRef, (snapshot) => {
      const data = snapshot.val();
      if (data) setPremiumConfig(data);
    });

    const unsubP = onValue(pRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setPackages(Object.entries(data).map(([id, val]: any) => ({ ...val, id })));
      } else {
        setPackages([]);
      }
    });

    return () => { unsubAuth(); unsubS(); unsubJ(); unsubC(); unsubP(); };
  }, []);

  if (authLoading) {
    return <div className="min-h-screen bg-white flex items-center justify-center font-black animate-pulse text-indigo-600 uppercase tracking-widest">JobPrep Pro Loading...</div>;
  }

  if (!state.user && state.currentView === 'AUTH') {
    return <Auth onSuccess={() => setState(prev => ({ ...prev, currentView: 'HOME' }))} />;
  }

  const subjects = [...INITIAL_SUBJECTS].map(initialSub => {
    const fromDb = dbSubjects.find(ds => ds.id === initialSub.id);
    return fromDb ? { ...initialSub, ...fromDb } : initialSub;
  });

  dbSubjects.forEach(dbSub => {
    if (!subjects.find(s => s.id === dbSub.id)) subjects.push(dbSub);
  });

  const jobs = [...INITIAL_JOBS].map(initialJob => {
    const fromDb = dbJobs.find(dj => dj.id === initialJob.id);
    return fromDb ? { ...initialJob, ...fromDb } : initialJob;
  });

  dbJobs.forEach(dbJob => {
    if (!jobs.find(j => j.id === dbJob.id)) jobs.push(dbJob);
  });

  const isPremium = state.user?.premiumExpiry ? state.user.premiumExpiry > Date.now() : false;
  const hasAccess = isPremium || (state.tempAccessExpiry && Date.now() < state.tempAccessExpiry);

  const navigateTo = (view: AppView, payload?: Partial<AppState>) => {
    setState(prev => ({ ...prev, currentView: view, ...payload }));
  };

  const handleOpenPdf = (url: string, title: string) => {
    if (hasAccess) {
      navigateTo('PDF_VIEWER', { selectedPdfUrl: url, selectedPdfTitle: title });
    } else {
      setShowPremiumModal(true);
    }
  };

  const handleSubmitTxId = (txId: string, pkg: SubscriptionPackage) => {
    if (!state.user) return;
    const txRef = ref(db, 'transactions');
    const newTxRef = push(txRef);
    set(newTxRef, {
      txId,
      userId: state.user.uid,
      userEmail: state.user.email,
      timestamp: Date.now(),
      status: 'pending',
      packageName: pkg.name,
      durationDays: pkg.days
    });
    setState(prev => ({ ...prev, pendingTxId: txId }));
  };

  const renderContent = () => {
    switch (state.currentView) {
      case 'HOME':
        return (
          <Home 
            subjects={subjects} 
            jobs={jobs} 
            onSelectSubject={(s) => navigateTo('SUBJECT_DETAILS', { selectedSubject: s })} 
            onExploreSectors={() => navigateTo('JOB_SECTORS')} 
            onNavigate={(view) => {
              if (view === 'EXAM' && !hasAccess) {
                setShowPremiumModal(true);
              } else {
                navigateTo(view);
              }
            }} 
          />
        );
      case 'EXAM':
        if (!hasAccess) {
          return <Home subjects={subjects} jobs={jobs} onSelectSubject={(s) => navigateTo('SUBJECT_DETAILS', { selectedSubject: s })} onExploreSectors={() => navigateTo('JOB_SECTORS')} onNavigate={navigateTo} />;
        }
        return <Exam onBack={() => navigateTo('HOME')} />;
      case 'JOB_SECTORS':
        return <JobSectors jobs={jobs} isPremium={hasAccess} onSelectJob={(job) => navigateTo('JOB_DETAILS', { selectedJob: job })} />;
      case 'SUBJECT_DETAILS':
        const targetSub = state.selectedSubject;
        return targetSub ? (
          <div className="px-8 py-10 max-w-6xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
             <div className="flex items-center space-x-6">
               <button onClick={() => navigateTo('HOME')} className="p-4 bg-white rounded-2xl shadow-sm hover:bg-slate-50 transition-colors"><ChevronLeft /></button>
               <h2 className="text-4xl font-black text-slate-900">{targetSub.name}</h2>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               {targetSub.chapters.map((c) => (
                 <button key={c.id} onClick={() => handleOpenPdf(c.pdfUrl, c.name)} className="group bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center justify-between hover:border-indigo-200 hover:shadow-xl hover:shadow-indigo-500/5 transition-all">
                   <div className="flex items-center space-x-6 text-left">
                     <div className={`p-5 rounded-3xl ${hasAccess ? 'bg-emerald-50 text-emerald-600' : 'bg-indigo-50 text-indigo-600'}`}>
                       {hasAccess ? <Unlock /> : <FileText />}
                     </div>
                     <div>
                        <span className="text-xl font-bold text-slate-800 block">{c.name}</span>
                        <span className={`text-[10px] font-black uppercase ${hasAccess ? 'text-emerald-500' : 'text-orange-400'}`}>{hasAccess ? 'Unlocked' : 'Locked'}</span>
                     </div>
                   </div>
                   <ChevronRight className="text-slate-300" />
                 </button>
               ))}
             </div>
          </div>
        ) : null;
      case 'JOB_DETAILS':
        const targetJob = state.selectedJob;
        return targetJob ? (
          <div className="px-8 py-10 max-w-6xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
             <div className="flex items-center space-x-6">
               <button onClick={() => navigateTo('JOB_SECTORS')} className="p-4 bg-white rounded-2xl shadow-sm hover:bg-slate-50 transition-colors"><ChevronLeft /></button>
               <h2 className="text-4xl font-black text-slate-900">{targetJob.name}</h2>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               {targetJob.chapters.map((c) => (
                 <button key={c.id} onClick={() => handleOpenPdf(c.pdfUrl, c.name)} className="group bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center justify-between hover:border-orange-200 hover:shadow-xl hover:shadow-orange-500/5 transition-all">
                   <div className="flex items-center space-x-6 text-left">
                     <div className={`p-5 rounded-3xl ${hasAccess ? 'bg-emerald-50 text-emerald-600' : 'bg-orange-50 text-orange-600'}`}>
                       {hasAccess ? <Unlock /> : <Briefcase />}
                     </div>
                     <div>
                        <span className="text-xl font-bold text-slate-800 block">{c.name}</span>
                        <span className={`text-[10px] font-black uppercase ${hasAccess ? 'text-emerald-500' : 'text-orange-400'}`}>{hasAccess ? 'Unlocked' : 'Locked'}</span>
                     </div>
                   </div>
                   <ChevronRight />
                 </button>
               ))}
             </div>
          </div>
        ) : null;
      case 'PDF_VIEWER':
        return <PdfViewer url={state.selectedPdfUrl || ''} title={state.selectedPdfTitle || ''} onBack={() => navigateTo('HOME')} />;
      default:
        return <Home subjects={subjects} jobs={jobs} onSelectSubject={(s) => navigateTo('SUBJECT_DETAILS', { selectedSubject: s })} onExploreSectors={() => navigateTo('JOB_SECTORS')} onNavigate={navigateTo} />;
    }
  };

  return (
    <Layout currentView={state.currentView} setView={(view) => {
      if (view === 'EXAM' && !hasAccess) {
        setShowPremiumModal(true);
      } else {
        navigateTo(view);
      }
    }} user={state.user} onOpenPremium={() => setShowPremiumModal(true)}>
      {renderContent()}
      {showPremiumModal && (
        <PremiumModal 
          config={premiumConfig}
          packages={packages}
          onClose={() => setShowPremiumModal(false)}
          onWatchAd={() => { setState(prev => ({ ...prev, tempAccessExpiry: Date.now() + 5*60000 })); setShowPremiumModal(false); }}
          onSubmitTxId={handleSubmitTxId}
          isPending={!!state.pendingTxId}
        />
      )}
    </Layout>
  );
};

export default App;
