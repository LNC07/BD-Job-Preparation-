
import React, { useState, useEffect } from 'react';
import { Crown, Gem, PlayCircle, X, ChevronRight, CheckCircle, ShieldCheck, Zap, AlertCircle, Loader2, Wifi, ExternalLink, Play, Globe } from 'lucide-react';
import { PremiumConfig, SubscriptionPackage } from '../types';

interface PremiumModalProps {
  config: PremiumConfig;
  packages: SubscriptionPackage[];
  onClose: () => void;
  onWatchAd: () => void;
  onSubmitTxId: (txId: string, pkg: SubscriptionPackage) => void;
  isPending: boolean;
}

const PremiumModal: React.FC<PremiumModalProps> = ({ config, packages, onClose, onWatchAd, onSubmitTxId, isPending }) => {
  const [step, setStep] = useState<'CHOICE' | 'PAYMENT' | 'AD'>('CHOICE');
  const [selectedPackage, setSelectedPackage] = useState<SubscriptionPackage | null>(null);
  const [txId, setTxId] = useState('');
  const [adCountdown, setAdCountdown] = useState(20); 
  const [adStatus, setAdStatus] = useState('Opening Ad Link...');

  useEffect(() => {
    let timer: any;
    if (step === 'AD' && adCountdown > 0) {
      timer = setInterval(() => {
        setAdCountdown(c => c - 1);
        
        if (adCountdown > 16) setAdStatus('Waiting for Ad interaction...');
        else if (adCountdown > 10) setAdStatus('Validating your session...');
        else if (adCountdown > 4) setAdStatus('Finalizing reward grant...');
        else setAdStatus('Verified! Redirecting...');
      }, 1000);
    } else if (step === 'AD' && adCountdown === 0) {
      onWatchAd();
    }
    return () => clearInterval(timer);
  }, [step, adCountdown, onWatchAd]);

  const handleStartAd = () => {
    setStep('AD');
    setAdCountdown(20);

    // Explicit Direct Link Trigger
    const targetUrl = config.directAdLink || 'https://vourtout.com/4/8557345'; // Fallback to a high-fill monetization link
    window.open(targetUrl, '_blank');
  };

  const handleSelectPackage = (pkg: SubscriptionPackage) => {
    setSelectedPackage(pkg);
    setStep('PAYMENT');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 md:px-0">
      <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md" onClick={onClose}></div>
      
      <div className="relative bg-white w-full max-w-lg rounded-[3rem] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
        {/* Header Decor */}
        <div className="bg-gradient-to-r from-indigo-700 via-purple-600 to-indigo-800 h-32 relative">
          <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-white/20 backdrop-blur-lg rounded-full text-white hover:bg-white/40 transition-all">
            <X className="w-5 h-5" />
          </button>
          <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-white p-4 rounded-3xl shadow-xl border border-slate-100">
             <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-4 rounded-2xl text-white shadow-lg shadow-orange-200">
                <Crown className="w-8 h-8" />
             </div>
          </div>
        </div>

        <div className="px-8 pt-16 pb-10 text-center">
          {step === 'CHOICE' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-3xl font-black text-slate-900 mb-2 tracking-tight">Premium Only</h2>
                <p className="text-slate-500 font-medium px-4">Unlock this content with a Pro plan or watch a quick ad.</p>
              </div>

              <div className="grid grid-cols-1 gap-3 max-h-64 overflow-y-auto pr-1">
                {packages.length > 0 ? packages.map(pkg => (
                  <button 
                    key={pkg.id}
                    onClick={() => handleSelectPackage(pkg)}
                    className="group flex items-center p-4 bg-white border-2 border-slate-100 rounded-[2rem] text-left hover:border-indigo-600 transition-all duration-300"
                  >
                    <div className="bg-indigo-50 p-3 rounded-2xl text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                      <Gem className="w-5 h-5" />
                    </div>
                    <div className="ml-4 flex-1">
                      <p className="font-black text-lg text-slate-800 leading-none mb-1">{pkg.name}</p>
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-tight">৳{pkg.price} • {pkg.days} Days</p>
                    </div>
                    <ChevronRight className="w-5 h-5 opacity-40 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                  </button>
                )) : (
                  <button 
                    onClick={() => handleSelectPackage({ id: 'default', name: 'Standard Pro', price: config.monthlyPrice, days: 30 })}
                    className="group flex items-center p-5 bg-indigo-50 border border-indigo-100 rounded-[2rem] text-left hover:bg-indigo-600 hover:text-white transition-all duration-300"
                  >
                    <div className="bg-white p-3 rounded-2xl text-indigo-600 group-hover:bg-indigo-500 group-hover:text-white transition-colors">
                      <Gem className="w-6 h-6" />
                    </div>
                    <div className="ml-4 flex-1">
                      <p className="font-bold text-lg">Monthly Premium</p>
                      <p className="text-xs opacity-70">Access for ৳{config.monthlyPrice}/mo</p>
                    </div>
                    <ChevronRight className="w-5 h-5 opacity-40" />
                  </button>
                )}
              </div>

              <div className="pt-2">
                <button 
                  onClick={handleStartAd}
                  className="w-full group flex items-center justify-center space-x-3 p-5 bg-slate-900 text-white rounded-[2rem] hover:bg-black transition-all shadow-xl shadow-slate-200 overflow-hidden relative"
                >
                  <div className="absolute inset-0 bg-indigo-500/10 animate-pulse"></div>
                  <PlayCircle className="w-7 h-7 text-indigo-400 relative z-10" />
                  <div className="text-left relative z-10">
                    <span className="font-black text-sm uppercase block">Watch Ad to Unlock</span>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">5 Minutes Pass</span>
                  </div>
                  <Zap className="w-5 h-5 text-yellow-400 animate-bounce relative z-10" />
                </button>
                <p className="mt-4 text-[9px] font-black uppercase text-slate-400 tracking-widest flex items-center justify-center space-x-2">
                   <Globe className="w-3 h-3" />
                   <span>External Ad Link Method</span>
                </p>
              </div>
            </div>
          )}

          {step === 'PAYMENT' && selectedPackage && (
            <div className="space-y-6 text-left">
              {isPending ? (
                <div className="text-center py-8">
                  <div className="bg-blue-50 text-blue-600 p-8 rounded-[3rem] inline-block mb-6 animate-pulse">
                    <ShieldCheck className="w-16 h-16" />
                  </div>
                  <h3 className="text-3xl font-black text-slate-900 mb-2">Request Submitted</h3>
                  <p className="text-slate-500 mb-8 font-medium">We are verifying your Transaction ID. Premium will be active shortly.</p>
                  <button onClick={onClose} className="w-full py-5 bg-slate-100 rounded-[2rem] font-black text-slate-600 hover:bg-slate-200 transition-all">Close</button>
                </div>
              ) : (
                <>
                  <div className="bg-indigo-50 p-6 rounded-[2.5rem] border border-indigo-100 relative overflow-hidden">
                    <div className="flex justify-between items-center mb-6 relative z-10">
                      <div>
                        <h4 className="font-black text-indigo-900 text-xl">{selectedPackage.name}</h4>
                        <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{selectedPackage.days} Days Access</p>
                      </div>
                      <span className="bg-white px-4 py-2 rounded-2xl text-indigo-600 font-black text-lg shadow-sm">৳{selectedPackage.price}</span>
                    </div>
                    <ol className="text-xs space-y-3 font-bold text-indigo-700/80 uppercase tracking-tight relative z-10">
                      <li className="flex items-center space-x-3">
                        <span className="bg-indigo-600 text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px] shrink-0">1</span>
                        <span>Send ৳{selectedPackage.price} to bKash: <span className="text-indigo-900 select-all font-black">{config.bkashNumber}</span></span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <span className="bg-indigo-600 text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px] shrink-0">2</span>
                        <span>Use "Send Money" Option</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <span className="bg-indigo-600 text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px] shrink-0">3</span>
                        <span>Copy & Paste Transaction ID below</span>
                      </li>
                    </ol>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Transaction ID</label>
                    <input 
                      type="text" 
                      placeholder="e.g. 8K3G9A1W" 
                      className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-[2rem] focus:ring-8 focus:ring-indigo-500/5 focus:bg-white focus:border-indigo-500 outline-none transition-all font-black tracking-widest text-lg"
                      value={txId}
                      onChange={(e) => setTxId(e.target.value.toUpperCase())}
                    />
                  </div>

                  <button 
                    onClick={() => txId && onSubmitTxId(txId, selectedPackage)}
                    disabled={!txId}
                    className="w-full py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-xl shadow-2xl shadow-indigo-100 hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center justify-center space-x-2"
                  >
                    <span>Activate Pro</span>
                    <CheckCircle className="w-6 h-6" />
                  </button>
                  <button onClick={() => setStep('CHOICE')} className="w-full text-sm font-bold text-slate-400 py-2 hover:text-slate-600 transition-colors">Select Another Plan</button>
                </>
              )}
            </div>
          )}

          {step === 'AD' && (
            <div className="py-12 space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="relative w-40 h-40 mx-auto">
                <div className="absolute inset-0 bg-indigo-100 rounded-full animate-ping opacity-25"></div>
                <div className="relative bg-white border-8 border-indigo-600 text-indigo-600 w-full h-full rounded-full flex flex-col items-center justify-center shadow-2xl">
                  <span className="text-5xl font-black tabular-nums leading-none">{adCountdown}</span>
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] mt-1">Seconds</span>
                </div>
                <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-4 py-1.5 rounded-full shadow-lg flex items-center space-x-2">
                  <Play className="w-3 h-3 fill-current" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Watching</span>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-3xl font-black text-slate-900 leading-tight">Reward Incoming...</h3>
                <p className="text-slate-500 font-medium px-10">Please keep the ad window open until the timer finishes.</p>
              </div>

              <div className="space-y-4">
                <div className="bg-slate-50 border border-slate-100 p-5 rounded-[2rem] inline-flex flex-col items-center space-y-2 w-full">
                  <div className="flex items-center space-x-3">
                    <Loader2 className="w-5 h-5 text-indigo-600 animate-spin" />
                    <span className="text-xs font-black text-slate-600 uppercase tracking-widest">{adStatus}</span>
                  </div>
                </div>

                <div className="px-6 space-y-3">
                   <button 
                    onClick={() => {
                      const targetUrl = config.directAdLink || 'https://vourtout.com/4/8557345';
                      window.open(targetUrl, '_blank');
                    }}
                    className="w-full flex items-center justify-center space-x-3 py-4 border-2 border-slate-200 text-slate-400 rounded-2xl font-black uppercase tracking-widest hover:border-indigo-600 hover:text-indigo-600 transition-all"
                   >
                     <ExternalLink className="w-5 h-5" />
                     <span>Refresh Ad Link</span>
                   </button>
                </div>
              </div>

              <div className="pt-4 px-12">
                <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden shadow-inner">
                   <div 
                    className="h-full bg-indigo-600 transition-all duration-1000"
                    style={{ width: `${(20 - adCountdown) * (100/20)}%` }}
                   ></div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PremiumModal;
