
import React, { useState, useEffect } from 'react';
import { AppView, UserProfile } from '../types';
import { auth } from '../lib/firebase';
import { 
  Home, Briefcase, LogOut, GraduationCap, Crown, MoreVertical, Star, Clock
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  currentView: AppView;
  setView: (view: AppView) => void;
  user: UserProfile | null;
  onOpenPremium: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, currentView, setView, user, onOpenPremium }) => {
  const [showMenu, setShowMenu] = useState(false);
  const [timeLeft, setTimeLeft] = useState('');

  const isPremium = user?.premiumExpiry ? user.premiumExpiry > Date.now() : false;

  useEffect(() => {
    if (!isPremium || !user?.premiumExpiry) return;

    const interval = setInterval(() => {
      const diff = user.premiumExpiry! - Date.now();
      if (diff <= 0) {
        setTimeLeft('Expired');
        return;
      }
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      setTimeLeft(`${days}d ${hours}h ${mins}m`);
    }, 1000);

    return () => clearInterval(interval);
  }, [isPremium, user?.premiumExpiry]);

  const handleLogout = async () => {
    try {
      await auth.signOut();
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#fafafa] overflow-hidden h-screen">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-72 bg-white border-r border-slate-100 p-8 space-y-10 z-30">
        <div className="flex items-center space-x-3 cursor-pointer group" onClick={() => setView('HOME')}>
          <div className="bg-indigo-600 p-2.5 rounded-2xl text-white shadow-xl shadow-indigo-100 group-hover:scale-110 transition-transform">
            <GraduationCap className="w-7 h-7" />
          </div>
          <div>
            <span className="text-xl font-extrabold tracking-tight text-slate-900 block">JobPrep<span className="text-indigo-600">Pro</span></span>
            <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-slate-400">Bangladesh Edition</span>
          </div>
        </div>

        <nav className="flex-1 space-y-2">
          <NavItem icon={<Home />} label="Dashboard" active={currentView === 'HOME'} onClick={() => setView('HOME')} />
          <NavItem icon={<Briefcase />} label="Job Sectors" active={currentView === 'JOB_SECTORS'} onClick={() => setView('JOB_SECTORS')} />
        </nav>

        <div className="pt-8 border-t border-slate-50">
          {!isPremium ? (
            <button 
              onClick={onOpenPremium}
              className="w-full bg-gradient-to-br from-yellow-400 to-orange-500 p-4 rounded-2xl mb-6 text-white shadow-lg shadow-orange-100 hover:scale-[1.02] transition-transform text-left group"
            >
              <div className="flex items-center justify-between mb-2">
                <Crown className="w-5 h-5" />
                <span className="text-[10px] font-black uppercase tracking-widest bg-white/20 px-2 py-0.5 rounded">Special</span>
              </div>
              <p className="font-extrabold text-sm mb-1 group-hover:underline">Upgrade to Pro</p>
              <p className="text-[10px] font-bold opacity-80 leading-tight">Unlock all PDFs & Mock Tests</p>
            </button>
          ) : (
            <div className="w-full bg-slate-900 p-5 rounded-[2rem] mb-6 text-white shadow-xl shadow-indigo-100 relative overflow-hidden group">
              <div className="absolute -right-4 -top-4 opacity-10 group-hover:scale-150 transition-transform duration-700">
                <Star className="w-24 h-24" />
              </div>
              <div className="relative z-10">
                <div className="flex items-center space-x-2 mb-2 text-indigo-400">
                  <Clock className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Premium: {timeLeft}</span>
                </div>
                <p className="font-black text-lg leading-tight">PREMIUM USER</p>
                <p className="text-[10px] font-bold opacity-70 mt-1 uppercase tracking-tighter">Unlimited Access</p>
              </div>
            </div>
          )}

          <div className="bg-slate-50 p-4 rounded-2xl mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold uppercase">
                {user?.email?.charAt(0) || 'U'}
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-bold text-slate-800 truncate">{user?.email?.split('@')[0] || 'User'}</p>
                <p className={`text-[10px] font-bold flex items-center space-x-1 ${isPremium ? 'text-indigo-600' : 'text-slate-400'}`}>
                   {isPremium && <Crown className="w-3 h-3" />}
                   <span>{isPremium ? 'PRO MEMBER' : 'FREE ACCOUNT'}</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Surface */}
      <main className="flex-1 flex flex-col relative h-full">
        <header className="bg-white/70 backdrop-blur-xl sticky top-0 z-40 px-8 py-5 flex items-center justify-between border-b border-slate-50">
          <div className="flex items-center space-x-6 flex-1">
             <div className="md:hidden flex items-center space-x-2" onClick={() => setView('HOME')}>
               <div className="bg-indigo-600 p-1.5 rounded-lg text-white">
                 <GraduationCap className="w-5 h-5" />
               </div>
               <span className="font-bold text-lg">JobPrep</span>
             </div>
             <div className="hidden md:block text-slate-400 font-medium text-sm">
               {isPremium ? 'Welcome, Premium Explorer! 🌟' : 'Welcome back, Learner!'}
             </div>
          </div>
          
          <div className="flex items-center space-x-3">
            {isPremium && (
               <div className="hidden lg:flex items-center space-x-2 bg-indigo-50 text-indigo-600 px-4 py-1.5 rounded-full border border-indigo-100">
                  <Crown className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">{timeLeft} Left</span>
               </div>
            )}
            
            <div className="relative">
              <button 
                onClick={() => setShowMenu(!showMenu)}
                className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded-xl transition-all"
              >
                <MoreVertical className="w-6 h-6" />
              </button>
              
              {showMenu && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setShowMenu(false)}></div>
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-2xl border border-slate-100 z-20 py-2 overflow-hidden animate-in fade-in zoom-in-95">
                    <button 
                      onClick={handleLogout}
                      className="w-full flex items-center space-x-3 px-4 py-3 text-sm font-bold text-red-500 hover:bg-red-50 transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Logout Account</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto pb-24 md:pb-10">
          {children}
        </div>

        {/* Mobile Nav */}
        <nav className="md:hidden bg-white/80 backdrop-blur-xl border-t border-slate-100 px-8 py-4 flex justify-around items-center fixed bottom-0 left-0 right-0 z-50">
          <MobileNavItem icon={<Home />} active={currentView === 'HOME'} onClick={() => setView('HOME')} />
          <MobileNavItem icon={<Briefcase />} active={currentView === 'JOB_SECTORS'} onClick={() => setView('JOB_SECTORS')} />
          {!isPremium ? (
            <button onClick={onOpenPremium} className="p-3.5 rounded-2xl text-slate-400">
              <Crown className="w-6 h-6" />
            </button>
          ) : (
            <div className="p-3.5 rounded-2xl text-indigo-600 bg-indigo-50">
               <Clock className="w-6 h-6" />
            </div>
          )}
        </nav>
      </main>
    </div>
  );
};

const NavItem = ({ icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-4 w-full px-5 py-3.5 rounded-2xl transition-all duration-300 group ${
      active 
        ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' 
        : 'text-slate-500 hover:bg-indigo-50 hover:text-indigo-600'
    }`}
  >
    {React.cloneElement(icon, { className: 'w-5 h-5' })}
    <span className="font-bold text-sm tracking-wide">{label}</span>
  </button>
);

const MobileNavItem = ({ icon, active, onClick }: { icon: any, active: boolean, onClick: () => void }) => (
  <button
    onClick={onClick}
    className={`p-3.5 rounded-2xl transition-all duration-300 ${
      active ? 'bg-indigo-600 text-white' : 'text-slate-400'
    }`}
  >
    {React.cloneElement(icon, { className: 'w-6 h-6' })}
  </button>
);

export default Layout;
