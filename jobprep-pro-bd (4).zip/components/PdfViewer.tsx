
import React, { useState, useEffect } from 'react';
import { ArrowLeft, ShieldCheck, Loader2, AlertCircle, Lock } from 'lucide-react';

interface PdfViewerProps {
  url: string;
  title: string;
  onBack: () => void;
}

const PdfViewer: React.FC<PdfViewerProps> = ({ url, title, onBack }) => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Disable right click to discourage saving/downloading
    const handleContextMenu = (e: MouseEvent) => e.preventDefault();
    document.addEventListener('contextmenu', handleContextMenu);
    return () => document.removeEventListener('contextmenu', handleContextMenu);
  }, []);

  // Google Docs Viewer with specific parameters to prevent toolbars where possible
  const googleViewerUrl = `https://docs.google.com/viewer?url=${encodeURIComponent(url)}&embedded=true`;

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-white overflow-hidden animate-in fade-in duration-500">
      {/* Immersive Header */}
      <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between z-20 shadow-2xl">
        <div className="flex items-center space-x-4 overflow-hidden">
          <button 
            onClick={onBack}
            className="p-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all active:scale-90 shrink-0"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="overflow-hidden">
            <h2 className="text-lg font-black truncate tracking-tight">{title}</h2>
            <div className="flex items-center space-x-1.5">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">JobPrep Secure Reader</p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2 bg-indigo-500/20 px-3 py-1.5 rounded-lg border border-white/5">
          <Lock className="w-3 h-3 text-indigo-400" />
          <span className="text-[10px] font-black uppercase text-indigo-300">View Only</span>
        </div>
      </div>

      {/* Main Content Area - Full Bleed */}
      <div className="flex-1 relative bg-slate-800 flex flex-col">
        {isLoading && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-slate-900">
            <Loader2 className="w-12 h-12 text-indigo-500 animate-spin mb-4" />
            <p className="text-white font-black text-lg">Decrypting PDF...</p>
            <p className="text-slate-500 text-sm font-bold mt-2">Loading secure document interface</p>
          </div>
        )}

        <iframe
          src={googleViewerUrl}
          className="w-full h-full border-none pointer-events-auto"
          onLoad={() => setIsLoading(false)}
          title={title}
          style={{ userSelect: 'none' }}
        />
        
        {/* Anti-screenshot/selection overlay (partial protection) */}
        <div className="absolute inset-0 pointer-events-none bg-indigo-500/5 mix-blend-overlay"></div>
      </div>
      
      {/* Floating Restriction Notice */}
      <div className="bg-slate-900/80 backdrop-blur-md text-white/50 text-[9px] font-bold py-2 text-center uppercase tracking-[0.3em]">
        Printing and Downloading is restricted for security. Content &copy; JobPrep Pro BD.
      </div>
    </div>
  );
};

export default PdfViewer;
