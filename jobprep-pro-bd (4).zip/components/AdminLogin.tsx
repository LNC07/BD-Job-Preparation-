
import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { ref, get } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";
import { Lock, ShieldAlert, ArrowLeft, Loader2 } from 'lucide-react';

interface AdminLoginProps {
  onLogin: (success: boolean) => void;
  onBack: () => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin, onBack }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(false);

    try {
      const configRef = ref(db, 'config');
      const snapshot = await get(configRef);
      const config = snapshot.val();
      const correctPassword = config?.adminPassword || '999';

      if (password === correctPassword) {
        onLogin(true);
      } else {
        setError(true);
        setTimeout(() => setError(false), 2000);
      }
    } catch (err) {
      console.error("Auth error", err);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center p-8 h-full">
      <div className="bg-white w-full max-w-md p-10 rounded-[3rem] shadow-2xl border border-slate-100 text-center space-y-8 animate-in zoom-in-95">
        <div className="inline-block p-5 bg-indigo-50 rounded-3xl text-indigo-600">
          <ShieldAlert className="w-12 h-12" />
        </div>
        
        <div>
          <h2 className="text-3xl font-black text-slate-900 mb-2">Admin Control</h2>
          <p className="text-slate-400 font-medium">Please enter the security password to access the dashboard.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className={`relative transition-all ${error ? 'animate-shake' : ''}`}>
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input 
              type="password" 
              placeholder="Security Key" 
              disabled={loading}
              className={`w-full bg-slate-50 border-2 ${error ? 'border-red-500' : 'border-slate-100'} px-12 py-4 rounded-2xl focus:bg-white focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold tracking-[0.5em] transition-all disabled:opacity-50`}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button 
            type="submit" 
            disabled={loading}
            className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black shadow-xl shadow-indigo-100 hover:bg-indigo-700 active:scale-95 transition-all flex items-center justify-center space-x-2"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <span>Authenticate</span>}
          </button>
        </form>

        <button 
          onClick={onBack}
          className="flex items-center justify-center space-x-2 text-slate-400 font-bold text-sm hover:text-slate-600 mx-auto"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to App</span>
        </button>
      </div>
    </div>
  );
};

export default AdminLogin;
