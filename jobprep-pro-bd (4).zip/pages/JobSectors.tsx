
import React, { useState } from 'react';
import { JobCategory } from '../types';
import { Briefcase, Building2, Landmark, GraduationCap, ChevronRight, Crown, Lock, Unlock } from 'lucide-react';

interface JobSectorsProps {
  jobs: JobCategory[];
  onSelectJob: (job: JobCategory) => void;
  isPremium: boolean;
}

const JobSectors: React.FC<JobSectorsProps> = ({ jobs, onSelectJob, isPremium }) => {
  const [activeFilter, setActiveFilter] = useState<'All' | 'Government' | 'Bank' | 'Teacher' | 'NGO'>('All');
  
  const filteredJobs = activeFilter === 'All' 
    ? jobs 
    : jobs.filter(j => j.sector === activeFilter);

  return (
    <div className="px-8 py-8 space-y-10 max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">Job Prep Sectors</h2>
          <p className="text-slate-400 font-medium text-lg mt-2">Targeted preparation for specific career goals</p>
        </div>
        
        <div className="flex bg-slate-100 p-1.5 rounded-2xl">
          {['All', 'Government', 'Bank', 'Teacher'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveFilter(tab as any)}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeFilter === tab ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredJobs.map((job) => (
          <div 
            key={job.id}
            onClick={() => onSelectJob(job)}
            className="group bg-white rounded-[2.5rem] border border-slate-100 p-8 shadow-sm hover:shadow-2xl transition-all duration-500 cursor-pointer relative overflow-hidden flex flex-col h-full"
          >
            <div className="absolute top-6 right-6">
               <div className={`p-2 rounded-xl transition-all ${isPremium ? 'bg-emerald-50 text-emerald-500' : 'bg-orange-50 text-orange-500 group-hover:bg-orange-500 group-hover:text-white'}`}>
                  {isPremium ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
               </div>
            </div>
            
            <div className="flex items-center space-x-3 mb-6">
              <span className={`px-4 py-1.5 rounded-full text-[10px] font-extrabold uppercase tracking-widest ${
                job.sector === 'Government' ? 'bg-orange-100 text-orange-600' :
                job.sector === 'Bank' ? 'bg-blue-100 text-blue-600' :
                'bg-emerald-100 text-emerald-600'
              }`}>
                {job.sector} Exam
              </span>
            </div>

            <h3 className="text-2xl font-extrabold text-slate-800 mb-4 group-hover:text-indigo-600 transition-colors leading-snug">
              {job.name}
            </h3>
            <p className="text-slate-400 font-medium mb-8 flex-1 leading-relaxed">
              {job.description}
            </p>

            <div className="pt-6 border-t border-slate-50 flex items-center justify-between">
              <span className="text-sm font-bold text-slate-500 flex items-center space-x-2">
                {isPremium ? <Crown className="w-4 h-4 text-indigo-600" /> : <Crown className="w-4 h-4 text-orange-400" />}
                <span>{isPremium ? 'Unlocked for Pro' : 'Premium Kit'}</span>
              </span>
              <div className="bg-slate-50 p-3 rounded-2xl group-hover:bg-indigo-600 group-hover:text-white transition-all">
                <ChevronRight className="w-6 h-6" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default JobSectors;
