
import React from 'react';
import { Subject, JobCategory, AppView } from '../types';
import { getIcon } from '../constants';
import { ChevronRight, Sparkles, TrendingUp, Users, Clock, ArrowRight, Zap, GraduationCap } from 'lucide-react';

interface HomeProps {
  subjects: Subject[];
  jobs: JobCategory[];
  onSelectSubject: (subject: Subject) => void;
  onExploreSectors: () => void;
  onNavigate: (view: AppView) => void;
}

const Home: React.FC<HomeProps> = ({ subjects, jobs, onSelectSubject, onExploreSectors, onNavigate }) => {
  return (
    <div className="px-8 py-8 space-y-12 max-w-7xl mx-auto">
      {/* Premium Hero Section */}
      <section className="relative overflow-hidden mesh-gradient rounded-[2.5rem] p-10 md:p-16 text-white shadow-2xl shadow-indigo-200">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-white/5 skew-x-12 translate-x-20"></div>
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center space-x-3 bg-white/10 backdrop-blur-md px-5 py-2 rounded-full text-xs font-bold mb-8 border border-white/10 uppercase tracking-widest">
            <Sparkles className="w-4 h-4 text-yellow-300" />
            <span>Next Generation Job Prep</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-[1.1] tracking-tight">
            Build Your <span className="text-indigo-200">Dream</span> Career Today.
          </h1>
          <p className="text-indigo-100/80 text-lg md:text-xl mb-10 max-w-xl font-medium leading-relaxed">
            Personalized learning paths for BCS, Bank, and Primary jobs with the most up-to-date resources in Bangladesh.
          </p>
          <div className="flex flex-wrap gap-5">
            <button 
              onClick={onExploreSectors}
              className="bg-white text-indigo-700 px-8 py-4 rounded-2xl font-bold premium-shadow hover:scale-105 transition-all flex items-center space-x-3"
            >
              <span>Explore Sectors</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            <button 
              onClick={() => onNavigate('EXAM')}
              className="bg-indigo-500/30 backdrop-blur-lg text-white border border-white/20 px-8 py-4 rounded-2xl font-bold hover:bg-indigo-500/50 transition-all flex items-center space-x-2"
            >
              <GraduationCap className="w-5 h-5" />
              <span>Take Exam</span>
            </button>
          </div>
        </div>
      </section>

      {/* Activity Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <ActivityCard label="Today's Progress" value="65%" sub="4/6 Chapters" icon={<Zap className="text-orange-500" />} />
        <ActivityCard label="Study Streak" value="12 Days" sub="Personal Best" icon={<TrendingUp className="text-indigo-500" />} />
        <ActivityCard label="Saved Resources" value="28" sub="PDFs & Notes" icon={<Clock className="text-emerald-500" />} />
        <ActivityCard label="Global Rank" value="#422" sub="Among 45K+" icon={<Users className="text-blue-500" />} />
      </div>

      {/* Modern Subject Grid */}
      <section>
        <div className="flex items-end justify-between mb-10 px-2">
          <div>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Core Knowledge</h2>
            <p className="text-slate-400 font-medium mt-1">Foundation subjects for any recruitment exam</p>
          </div>
          <button className="text-indigo-600 font-bold text-sm hover:underline flex items-center space-x-1">
            <span>View All</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {subjects.map((subject) => (
            <div
              key={subject.id}
              onClick={() => onSelectSubject(subject)}
              className="group bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:shadow-indigo-500/10 hover:-translate-y-2 transition-all duration-500 cursor-pointer text-center relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-indigo-50/0 to-indigo-50/50 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative z-10">
                <div className="mx-auto w-20 h-20 bg-slate-50 text-slate-400 p-6 rounded-3xl mb-6 group-hover:bg-indigo-600 group-hover:text-white group-hover:rotate-6 transition-all duration-500 shadow-sm">
                  {getIcon(subject.icon, "w-full h-full")}
                </div>
                <h3 className="text-xl font-extrabold text-slate-800 mb-2">{subject.name}</h3>
                <p className="text-slate-400 text-sm font-bold uppercase tracking-widest">{subject.chapters.length} Modules</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Sector Teaser */}
      <section className="bg-slate-900 rounded-[3rem] p-12 text-white flex flex-col md:flex-row items-center justify-between gap-10">
          <div className="max-w-xl">
            <h3 className="text-3xl font-extrabold mb-4 tracking-tight">Focus on BCS Preparation?</h3>
            <p className="text-slate-400 text-lg leading-relaxed">
              Our 46th BCS Masterclass includes exclusive syllabus analysis, previous year question banks, and simulated prelims.
            </p>
          </div>
          <button 
            onClick={onExploreSectors}
            className="whitespace-nowrap bg-indigo-600 px-10 py-5 rounded-2xl font-bold premium-shadow hover:bg-indigo-500 transition-all flex items-center space-x-3"
          >
            <span>Access BCS Hub</span>
            <ArrowRight className="w-5 h-5" />
          </button>
      </section>
    </div>
  );
};

const ActivityCard = ({ label, value, sub, icon }: { label: string, value: string, sub: string, icon: any }) => (
  <div className="bg-white p-6 rounded-3xl border border-slate-50 shadow-sm hover:shadow-md transition-all flex items-start space-x-4">
    <div className="p-3 bg-slate-50 rounded-2xl">
      {icon}
    </div>
    <div>
      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{label}</p>
      <p className="text-2xl font-extrabold text-slate-900 mb-0.5">{value}</p>
      <p className="text-xs font-medium text-slate-500">{sub}</p>
    </div>
  </div>
);

export default Home;
