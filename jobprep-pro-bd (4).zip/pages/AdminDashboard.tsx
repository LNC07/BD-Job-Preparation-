
import React, { useState, useEffect } from 'react';
import { db, storage } from '../lib/firebase';
import { ref, set, push, onValue, remove, update, get } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";
import { ref as sRef, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-storage.js";
import { Subject, JobCategory, Chapter, PendingTransaction, PremiumConfig, MCQ, SubscriptionPackage } from '../types';
import { 
  Plus, Trash2, Edit3, Save, X, FilePlus, ChevronDown, 
  ChevronUp, Check, XCircle, Database, Smartphone, DollarSign, UploadCloud, Settings, 
  BookOpen, FileText, LayoutGrid, Library, AlertTriangle, Loader2, Briefcase, CheckCircle2, KeyRound, GraduationCap, Package, Zap, Globe, Link2, ExternalLink
} from 'lucide-react';

interface AdminDashboardProps {
  subjects: Subject[];
  jobs: JobCategory[];
  config: PremiumConfig;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ subjects, jobs, config }) => {
  const [activeTab, setActiveTab] = useState<'UPLOAD' | 'MANAGE' | 'PAYMENTS' | 'CONFIG' | 'EXAM' | 'PACKAGES' | 'ADS'>('UPLOAD');
  const [transactions, setTransactions] = useState<PendingTransaction[]>([]);
  const [packages, setPackages] = useState<SubscriptionPackage[]>([]);
  const [uploading, setUploading] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  
  // Forms
  const [subUploadForm, setSubUploadForm] = useState({ subjectId: '', chapterName: '', file: null as File | null });
  const [jobUploadForm, setJobUploadForm] = useState({ jobId: '', chapterName: '', file: null as File | null });
  const [newSubjectName, setNewSubjectName] = useState('');
  const [newJobForm, setNewJobForm] = useState({ name: '', sector: 'Government' as any, description: '' });
  const [newPackage, setNewPackage] = useState({ name: '', price: 0, days: 30 });
  const [tempConfig, setTempConfig] = useState<PremiumConfig>({
    bkashNumber: config.bkashNumber,
    monthlyPrice: config.monthlyPrice,
    adminPassword: config.adminPassword || '999',
    directAdLink: config.directAdLink || ''
  });

  // Exam Form
  const [examTime, setExamTime] = useState(20);
  const [examQuestions, setExamQuestions] = useState<MCQ[]>([]);
  const [newMCQ, setNewMCQ] = useState({ question: '', options: ['', '', '', ''], correctAnswer: 0 });

  useEffect(() => { 
    setTempConfig({
      bkashNumber: config.bkashNumber,
      monthlyPrice: config.monthlyPrice,
      adminPassword: config.adminPassword || '999',
      directAdLink: config.directAdLink || ''
    }); 
  }, [config]);

  useEffect(() => {
    const txRef = ref(db, 'transactions');
    const examRef = ref(db, 'exam');
    const packRef = ref(db, 'packages');

    const unsubTx = onValue(txRef, (snapshot) => {
      const data = snapshot.val();
      if (data) setTransactions(Object.entries(data).map(([id, val]: any) => ({ ...val, id })));
    });

    const unsubExam = onValue(examRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setExamTime(data.timeLimit || 20);
        setExamQuestions(data.questions ? Object.values(data.questions) : []);
      }
    });

    const unsubPacks = onValue(packRef, (snapshot) => {
      const data = snapshot.val();
      if (data) setPackages(Object.entries(data).map(([id, val]: any) => ({ ...val, id })));
      else setPackages([]);
    });

    return () => { unsubTx(); unsubExam(); unsubPacks(); };
  }, []);

  const triggerSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  const handleApprove = async (tx: PendingTransaction) => {
    const days = tx.durationDays || 30;
    const expiry = Date.now() + (days * 24 * 60 * 60 * 1000); 
    await update(ref(db, `transactions/${tx.id}`), { status: 'approved' });
    await update(ref(db, `users/${tx.userId}`), { 
      isPremium: true,
      premiumExpiry: expiry
    });
    triggerSuccess(`Premium activated for ${days} days!`);
  };

  const handleAddPackage = () => {
    if (!newPackage.name || newPackage.price <= 0 || newPackage.days <= 0) return;
    const newPackRef = push(ref(db, 'packages'));
    set(newPackRef, { ...newPackage, id: newPackRef.key });
    setNewPackage({ name: '', price: 0, days: 30 });
    triggerSuccess("Package Created!");
  };

  const handleAddMCQ = () => {
    if (!newMCQ.question || newMCQ.options.some(o => !o)) return;
    const qId = Math.random().toString(36).substr(2, 9);
    set(ref(db, `exam/questions/${qId}`), { ...newMCQ, id: qId });
    setNewMCQ({ question: '', options: ['', '', '', ''], correctAnswer: 0 });
    triggerSuccess("MCQ Added!");
  };

  const handleFileUpload = async (file: File, path: string) => {
    const fileRef = sRef(storage, `${path}/${Date.now()}_${file.name}`);
    await uploadBytes(fileRef, file);
    return await getDownloadURL(fileRef);
  };

  const handleUploadToSubject = async () => {
    if (!subUploadForm.subjectId || !subUploadForm.chapterName || !subUploadForm.file) return;
    setUploading(true);
    try {
      const pdfUrl = await handleFileUpload(subUploadForm.file, `pdfs/subjects/${subUploadForm.subjectId}`);
      const newRef = push(ref(db, `subjects/${subUploadForm.subjectId}/chapters`));
      await set(newRef, { name: subUploadForm.chapterName, pdfUrl, id: newRef.key });
      setSubUploadForm({ subjectId: '', chapterName: '', file: null });
      triggerSuccess("Upload Success: Subject PDF uploaded!");
    } catch (err: any) { alert(err.message); } finally { setUploading(false); }
  };

  const handleUploadToJob = async () => {
    if (!jobUploadForm.jobId || !jobUploadForm.chapterName || !jobUploadForm.file) return;
    setUploading(true);
    try {
      const pdfUrl = await handleFileUpload(jobUploadForm.file, `pdfs/jobs/${jobUploadForm.jobId}`);
      const newRef = push(ref(db, `jobs/${jobUploadForm.jobId}/chapters`));
      await set(newRef, { name: jobUploadForm.chapterName, pdfUrl, id: newRef.key });
      setJobUploadForm({ jobId: '', chapterName: '', file: null });
      triggerSuccess("Upload Success: Job Material uploaded!");
    } catch (err: any) { alert(err.message); } finally { setUploading(false); }
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-10 pb-32 relative">
      {successMessage && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[200] animate-in slide-in-from-top-4 fade-in duration-300">
          <div className="bg-emerald-600 text-white px-8 py-4 rounded-3xl shadow-2xl shadow-emerald-200 flex items-center space-x-3">
            <CheckCircle2 className="w-6 h-6" />
            <span className="font-black text-sm uppercase tracking-wider">{successMessage}</span>
          </div>
        </div>
      )}

      <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden">
        <div className="flex bg-slate-50 border-b border-slate-100 p-2 overflow-x-auto">
          <TabBtn active={activeTab === 'UPLOAD'} onClick={() => setActiveTab('UPLOAD')} icon={<UploadCloud />} label="Quick Upload" />
          <TabBtn active={activeTab === 'MANAGE'} onClick={() => setActiveTab('MANAGE')} icon={<LayoutGrid />} label="Manage Library" />
          <TabBtn active={activeTab === 'EXAM'} onClick={() => setActiveTab('EXAM')} icon={<GraduationCap />} label="Manage Exam" />
          <TabBtn active={activeTab === 'PACKAGES'} onClick={() => setActiveTab('PACKAGES')} icon={<Package />} label="Packages" />
          <TabBtn active={activeTab === 'ADS'} onClick={() => setActiveTab('ADS')} icon={<Zap />} label="Direct Ads" />
          <TabBtn active={activeTab === 'PAYMENTS'} onClick={() => setActiveTab('PAYMENTS')} icon={<Check />} label="Premium Requests" />
          <TabBtn active={activeTab === 'CONFIG'} onClick={() => setActiveTab('CONFIG')} icon={<Settings />} label="Settings" />
        </div>

        <div className="p-8 md:p-12">
          {activeTab === 'ADS' && (
            <div className="space-y-10">
              <div className="border-b border-slate-100 pb-6">
                <h3 className="text-3xl font-black text-slate-900">Direct Ads System</h3>
                <p className="text-slate-500 font-medium">Configure a direct link for users to watch ads (Monetag Direct Link, etc.)</p>
              </div>

              <div className="max-w-2xl bg-indigo-50 p-10 rounded-[3rem] border border-indigo-100 space-y-6">
                <div className="flex items-center space-x-4 mb-2">
                   <div className="bg-indigo-600 p-4 rounded-3xl text-white shadow-xl shadow-indigo-200">
                      <Link2 className="w-8 h-8" />
                   </div>
                   <div>
                      <h4 className="text-xl font-black text-slate-800">Ad Link Configuration</h4>
                      <p className="text-xs text-indigo-600 font-bold uppercase tracking-widest">Recommended: Monetag Direct Link</p>
                   </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-500 uppercase tracking-widest ml-1">Your Direct Ad URL</label>
                  <div className="relative">
                    <input 
                      className="w-full p-5 pl-14 rounded-2xl border-2 border-slate-200 font-bold text-sm outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 transition-all"
                      placeholder="https://example.com/direct-ad-link"
                      value={tempConfig.directAdLink}
                      onChange={e => setTempConfig({...tempConfig, directAdLink: e.target.value})}
                    />
                    <Globe className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-400" />
                  </div>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-indigo-100">
                   <h5 className="font-bold text-slate-800 mb-2 flex items-center space-x-2">
                      <AlertTriangle className="w-4 h-4 text-orange-500" />
                      <span>How it works:</span>
                   </h5>
                   <ul className="text-xs text-slate-500 space-y-2 font-medium">
                      <li>• When a user clicks "Watch Ad", this link will open in a new tab.</li>
                      <li>• The app will start a 15-20 second countdown automatically.</li>
                      <li>• After the countdown, the user gets 5 minutes of temporary access.</li>
                      <li>• Use a direct link from networks like Monetag, Adsterra, or any URL.</li>
                   </ul>
                </div>

                <button 
                  onClick={() => set(ref(db, 'config'), tempConfig).then(() => triggerSuccess("Ad Link Saved!"))}
                  className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-lg shadow-xl hover:bg-black transition-all flex items-center justify-center space-x-2"
                >
                  <Save className="w-5 h-5" />
                  <span>Update Ad Configuration</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'PACKAGES' && (
            <div className="space-y-12">
               <div className="bg-indigo-50 p-8 rounded-[2.5rem] border border-indigo-100">
                  <h3 className="text-xl font-black text-slate-800 mb-6 flex items-center space-x-2">
                    <Plus className="text-indigo-600" />
                    <span>Create New Subscription Package</span>
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-black text-slate-500 uppercase">Package Name</label>
                      <input 
                        className="w-full p-4 rounded-xl border border-slate-200 font-bold" 
                        placeholder="e.g. Monthly Pro" 
                        value={newPackage.name}
                        onChange={e => setNewPackage({...newPackage, name: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black text-slate-500 uppercase">Price (BDT)</label>
                      <input 
                        type="number"
                        className="w-full p-4 rounded-xl border border-slate-200 font-bold" 
                        placeholder="e.g. 150" 
                        value={newPackage.price}
                        onChange={e => setNewPackage({...newPackage, price: parseInt(e.target.value) || 0})}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black text-slate-500 uppercase">Duration (Days)</label>
                      <input 
                        type="number"
                        className="w-full p-4 rounded-xl border border-slate-200 font-bold" 
                        placeholder="e.g. 30" 
                        value={newPackage.days}
                        onChange={e => setNewPackage({...newPackage, days: parseInt(e.target.value) || 0})}
                      />
                    </div>
                  </div>
                  <button 
                    onClick={handleAddPackage}
                    className="mt-6 w-full bg-indigo-600 text-white py-4 rounded-xl font-black shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
                  >
                    Add Package
                  </button>
               </div>

               <div className="space-y-6">
                  <h3 className="text-2xl font-black text-slate-900">Current Packages</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {packages.map(p => (
                      <div key={p.id} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col justify-between">
                        <div>
                          <p className="font-black text-xl text-slate-800 mb-1">{p.name}</p>
                          <p className="text-indigo-600 font-black text-2xl">৳{p.price}</p>
                          <p className="text-slate-400 font-bold text-sm mt-1">{p.days} Days Validity</p>
                        </div>
                        <button 
                          onClick={() => remove(ref(db, `packages/${p.id}`))}
                          className="mt-4 text-red-400 hover:text-red-600 font-bold text-sm flex items-center space-x-1"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>Remove</span>
                        </button>
                      </div>
                    ))}
                    {packages.length === 0 && <p className="text-slate-400 font-bold italic py-10">No packages defined.</p>}
                  </div>
               </div>
            </div>
          )}

          {activeTab === 'EXAM' && (
            <div className="space-y-12">
               <div className="bg-indigo-50 p-8 rounded-[2.5rem] border border-indigo-100 flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-black text-slate-800">Exam Time Limit</h3>
                    <p className="text-slate-500 text-sm font-bold">Set the total duration for the entire exam</p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <input 
                      type="number" 
                      className="w-24 p-4 rounded-xl border-2 border-indigo-200 font-black text-center" 
                      value={examTime} 
                      onChange={e => setExamTime(parseInt(e.target.value) || 0)} 
                    />
                    <button 
                      onClick={() => set(ref(db, 'exam/timeLimit'), examTime).then(() => triggerSuccess("Time Saved!"))}
                      className="bg-indigo-600 text-white px-6 py-4 rounded-xl font-black"
                    >
                      Save
                    </button>
                  </div>
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="space-y-6">
                    <h3 className="text-2xl font-black text-slate-900 flex items-center space-x-2">
                      <Plus className="text-indigo-600" />
                      <span>Add New MCQ (Total: {examQuestions.length})</span>
                    </h3>
                    <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 space-y-4">
                      <textarea 
                        className="w-full p-4 rounded-xl border border-slate-200 font-bold h-24 resize-none" 
                        placeholder="Question text..." 
                        value={newMCQ.question}
                        onChange={e => setNewMCQ({...newMCQ, question: e.target.value})}
                      />
                      <div className="grid grid-cols-1 gap-2">
                        {newMCQ.options.map((opt, i) => (
                          <div key={i} className="flex items-center space-x-2">
                            <input 
                              type="radio" 
                              name="correct" 
                              checked={newMCQ.correctAnswer === i} 
                              onChange={() => setNewMCQ({...newMCQ, correctAnswer: i})}
                            />
                            <input 
                              className="flex-1 p-3 rounded-lg border border-slate-200 font-medium" 
                              placeholder={`Option ${String.fromCharCode(65+i)}`}
                              value={opt}
                              onChange={e => {
                                const newOpts = [...newMCQ.options];
                                newOpts[i] = e.target.value;
                                setNewMCQ({...newMCQ, options: newOpts});
                              }}
                            />
                          </div>
                        ))}
                      </div>
                      <button 
                        onClick={handleAddMCQ}
                        className="w-full bg-indigo-600 text-white py-4 rounded-xl font-black shadow-lg shadow-indigo-100"
                      >
                        Add to Exam
                      </button>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h3 className="text-2xl font-black text-slate-900">Exam Question Bank</h3>
                    <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
                      {examQuestions.map((q, idx) => (
                        <div key={q.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
                           <div className="flex justify-between items-start mb-2">
                             <span className="font-black text-slate-800">Q{idx+1}. {q.question.substring(0, 40)}...</span>
                             <button onClick={() => remove(ref(db, `exam/questions/${q.id}`))} className="text-red-400 hover:text-red-600"><Trash2 className="w-4 h-4"/></button>
                           </div>
                           <p className="text-[10px] font-black uppercase text-emerald-500">Answer: {String.fromCharCode(65 + q.correctAnswer)}</p>
                        </div>
                      ))}
                      {examQuestions.length === 0 && <p className="text-center text-slate-400 py-10 font-bold italic">Bank is empty.</p>}
                    </div>
                  </div>
               </div>
            </div>
          )}

          {activeTab === 'PAYMENTS' && (
            <div className="space-y-6">
              <h3 className="text-2xl font-black text-slate-900">Pending Approvals</h3>
              {transactions.filter(t => t.status === 'pending').map(tx => (
                <div key={tx.id} className="bg-indigo-50/50 p-8 rounded-[2.5rem] border border-indigo-100 flex items-center justify-between">
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <p className="text-xs font-black text-indigo-400 uppercase tracking-[0.2em]">TXID: {tx.txId}</p>
                      {tx.packageName && <span className="px-2 py-0.5 bg-indigo-100 text-indigo-600 text-[10px] font-black rounded-full uppercase">{tx.packageName}</span>}
                    </div>
                    <p className="text-xl font-bold text-slate-800">{tx.userEmail}</p>
                    <p className="text-xs text-slate-400 mt-1">Requested: {new Date(tx.timestamp).toLocaleString()} • Duration: {tx.durationDays || 30} days</p>
                  </div>
                  <div className="flex space-x-3">
                    <button onClick={() => handleApprove(tx)} className="p-5 bg-emerald-500 text-white rounded-3xl hover:bg-emerald-600 shadow-xl shadow-emerald-50"><Check /></button>
                    <button onClick={() => update(ref(db, `transactions/${tx.id}`), { status: 'rejected' })} className="p-5 bg-red-500 text-white rounded-3xl hover:bg-red-600"><XCircle /></button>
                  </div>
                </div>
              ))}
              {transactions.filter(t => t.status === 'pending').length === 0 && <p className="text-center text-slate-400 font-bold py-10">No pending requests.</p>}
            </div>
          )}

          {activeTab === 'UPLOAD' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div className="space-y-6">
                <h3 className="text-2xl font-black text-indigo-600 flex items-center space-x-2"><BookOpen /> <span>Subject PDF</span></h3>
                <div className="bg-indigo-50/30 p-8 rounded-[2rem] border border-indigo-100 space-y-4">
                  <select className="w-full p-4 rounded-xl border border-slate-200 font-bold outline-none focus:ring-2 focus:ring-indigo-500" value={subUploadForm.subjectId} onChange={e => setSubUploadForm({...subUploadForm, subjectId: e.target.value})}>
                    <option value="">Select Subject</option>
                    {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                  <input className="w-full p-4 rounded-xl border border-slate-200 font-bold outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Chapter Name" value={subUploadForm.chapterName} onChange={e => setSubUploadForm({...subUploadForm, chapterName: e.target.value})} />
                  <div className="p-4 border-2 border-dashed border-slate-200 rounded-xl bg-white text-center">
                    <input type="file" id="subFile" className="hidden" onChange={e => setSubUploadForm({...subUploadForm, file: e.target.files?.[0] || null})} />
                    <label htmlFor="subFile" className="cursor-pointer text-sm font-bold text-slate-500 hover:text-indigo-600">
                      {subUploadForm.file ? subUploadForm.file.name : "Select PDF File"}
                    </label>
                  </div>
                  <button 
                    disabled={uploading || !subUploadForm.file || !subUploadForm.chapterName} 
                    onClick={handleUploadToSubject} 
                    className="w-full bg-indigo-600 text-white py-5 rounded-xl font-black shadow-lg shadow-indigo-100 disabled:opacity-50 hover:bg-indigo-700 transition-all flex items-center justify-center space-x-2"
                  >
                    {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <UploadCloud className="w-5 h-5" />}
                    <span>{uploading ? "Uploading..." : "Upload Subject PDF"}</span>
                  </button>
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-2xl font-black text-orange-600 flex items-center space-x-2"><Briefcase /> <span>Job PDF</span></h3>
                <div className="bg-orange-50/30 p-8 rounded-[2rem] border border-orange-100 space-y-4">
                  <select className="w-full p-4 rounded-xl border border-slate-200 font-bold outline-none focus:ring-2 focus:ring-orange-500" value={jobUploadForm.jobId} onChange={e => setJobUploadForm({...jobUploadForm, jobId: e.target.value})}>
                    <option value="">Select Job Sector</option>
                    {jobs.map(j => <option key={j.id} value={j.id}>{j.name}</option>)}
                  </select>
                  <input className="w-full p-4 rounded-xl border border-slate-200 font-bold outline-none focus:ring-2 focus:ring-orange-500" placeholder="Material Name" value={jobUploadForm.chapterName} onChange={e => setJobUploadForm({...jobUploadForm, chapterName: e.target.value})} />
                  <div className="p-4 border-2 border-dashed border-slate-200 rounded-xl bg-white text-center">
                    <input type="file" id="jobFile" className="hidden" onChange={e => setJobUploadForm({...jobUploadForm, file: e.target.files?.[0] || null})} />
                    <label htmlFor="jobFile" className="cursor-pointer text-sm font-bold text-slate-500 hover:text-orange-600">
                      {jobUploadForm.file ? jobUploadForm.file.name : "Select PDF File"}
                    </label>
                  </div>
                  <button 
                    disabled={uploading || !jobUploadForm.file || !jobUploadForm.chapterName} 
                    onClick={handleUploadToJob} 
                    className="w-full bg-orange-600 text-white py-5 rounded-xl font-black shadow-lg shadow-orange-100 disabled:opacity-50 hover:bg-orange-700 transition-all flex items-center justify-center space-x-2"
                  >
                    {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <UploadCloud className="w-5 h-5" />}
                    <span>{uploading ? "Uploading..." : "Upload Job PDF"}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'CONFIG' && (
            <div className="max-w-md mx-auto space-y-6">
               <div className="space-y-2">
                 <label className="text-sm font-black text-slate-500 ml-1">bKash Payment Number</label>
                 <input className="w-full p-4 rounded-xl border font-bold focus:ring-2 focus:ring-indigo-500 outline-none" value={tempConfig.bkashNumber} onChange={e => setTempConfig({...tempConfig, bkashNumber: e.target.value})} placeholder="bKash No." />
               </div>
               
               <div className="space-y-2">
                 <label className="text-sm font-black text-slate-500 ml-1">Default Monthly Price (Fallback)</label>
                 <input type="number" className="w-full p-4 rounded-xl border font-bold focus:ring-2 focus:ring-indigo-500 outline-none" value={tempConfig.monthlyPrice} onChange={e => setTempConfig({...tempConfig, monthlyPrice: parseInt(e.target.value) || 0})} placeholder="Price" />
               </div>

               <div className="space-y-2 pt-4 border-t border-slate-100">
                 <label className="text-sm font-black text-indigo-600 ml-1 flex items-center space-x-1">
                   <KeyRound className="w-4 h-4" />
                   <span>Admin Panel Password</span>
                 </label>
                 <input 
                  type="text" 
                  className="w-full p-4 rounded-xl border-2 border-indigo-50 font-black tracking-widest focus:border-indigo-500 outline-none" 
                  value={tempConfig.adminPassword} 
                  onChange={e => setTempConfig({...tempConfig, adminPassword: e.target.value})} 
                  placeholder="New Admin Password" 
                 />
                 <p className="text-[10px] text-slate-400 font-bold ml-1 italic">This is the code you use to enter this dashboard (default is 999).</p>
               </div>

               <button onClick={() => set(ref(db, 'config'), tempConfig).then(() => triggerSuccess("Settings Saved!"))} className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all">Save Settings</button>
            </div>
          )}
          
          {activeTab === 'MANAGE' && (
            <div className="space-y-12">
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div className="bg-indigo-50 p-8 rounded-3xl border border-indigo-100">
                    <h4 className="text-lg font-black text-indigo-900 mb-4">New Subject Category</h4>
                    <div className="flex space-x-2">
                      <input className="flex-1 p-4 rounded-xl border border-indigo-100 font-bold" placeholder="Subject Name" value={newSubjectName} onChange={e => setNewSubjectName(e.target.value)} />
                      <button onClick={() => {
                        if (!newSubjectName.trim()) return;
                        const sId = newSubjectName.toLowerCase().replace(/\s+/g, '_');
                        set(ref(db, `subjects/${sId}`), { id: sId, name: newSubjectName, icon: 'Book', chapters: [] });
                        setNewSubjectName('');
                        triggerSuccess("Subject Category Created!");
                      }} className="bg-indigo-600 text-white px-6 rounded-xl font-bold">Create</button>
                    </div>
                 </div>
                 <div className="bg-orange-50 p-8 rounded-3xl border border-orange-100">
                    <h4 className="text-lg font-black text-orange-900 mb-4">New Job Category</h4>
                    <div className="space-y-2">
                      <input className="w-full p-4 rounded-xl border border-orange-100 font-bold" placeholder="Job Title" value={newJobForm.name} onChange={e => setNewJobForm({...newJobForm, name: e.target.value})} />
                      <button onClick={() => {
                        if (!newJobForm.name.trim()) return;
                        const jId = newJobForm.name.toLowerCase().replace(/\s+/g, '_');
                        set(ref(db, `jobs/${jId}`), { ...newJobForm, id: jId, chapters: [] });
                        setNewJobForm({ name: '', sector: 'Government', description: '' });
                        triggerSuccess("Job Category Created!");
                      }} className="w-full bg-orange-600 text-white py-4 rounded-xl font-bold">Create Category</button>
                    </div>
                 </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <h3 className="text-xl font-black flex items-center space-x-2"><Library className="w-5 h-5" /> <span>Subjects</span></h3>
                    {subjects.map(s => (
                      <div key={s.id} className="bg-white border border-slate-100 p-5 rounded-[2rem] shadow-sm">
                        <div className="flex justify-between items-center mb-4">
                          <span className="font-black text-slate-800">{s.name} <span className="text-indigo-500 font-medium ml-1">({s.chapters.length})</span></span>
                          <button onClick={() => { if(window.confirm("Delete entire subject?")) remove(ref(db, `subjects/${s.id}`)) }} className="p-2 hover:bg-red-50 text-red-400 rounded-lg transition-colors"><Trash2 className="w-4 h-4"/></button>
                        </div>
                        <div className="space-y-2">
                          {s.chapters.map(c => (
                            <div key={c.id} className="flex justify-between items-center text-xs p-3 bg-slate-50 rounded-xl border border-slate-100">
                              <span className="font-bold text-slate-600">{c.name}</span>
                              <button onClick={() => { if(window.confirm("Delete this chapter?")) remove(ref(db, `subjects/${s.id}/chapters/${c.id}`)) }} className="text-slate-300 hover:text-red-500 transition-colors"><X className="w-3 h-3"/></button>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-xl font-black flex items-center space-x-2"><Briefcase className="w-5 h-5" /> <span>Job Sectors</span></h3>
                    {jobs.map(j => (
                      <div key={j.id} className="bg-white border border-slate-100 p-5 rounded-[2rem] shadow-sm">
                        <div className="flex justify-between items-center mb-4">
                          <span className="font-black text-slate-800">{j.name} <span className="text-orange-500 font-medium ml-1">({j.chapters.length})</span></span>
                          <button onClick={() => { if(window.confirm("Delete entire job sector?")) remove(ref(db, `jobs/${j.id}`)) }} className="p-2 hover:bg-red-50 text-red-400 rounded-lg transition-colors"><Trash2 className="w-4 h-4"/></button>
                        </div>
                        <div className="space-y-2">
                          {j.chapters.map(c => (
                            <div key={c.id} className="flex justify-between items-center text-xs p-3 bg-slate-50 rounded-xl border border-slate-100">
                              <span className="font-bold text-slate-600">{c.name}</span>
                              <button onClick={() => { if(window.confirm("Delete this material?")) remove(ref(db, `jobs/${j.id}/chapters/${c.id}`)) }} className="text-slate-300 hover:text-red-500 transition-colors"><X className="w-3 h-3"/></button>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const TabBtn = ({ active, onClick, icon, label }: any) => (
  <button onClick={onClick} className={`flex-shrink-0 flex items-center space-x-2 px-6 py-5 rounded-2xl font-black text-sm transition-all ${active ? 'bg-white text-indigo-600 shadow-xl' : 'text-slate-400'}`}>
    {React.cloneElement(icon, { className: 'w-5 h-5' })}
    <span className="uppercase tracking-widest">{label}</span>
  </button>
);

export default AdminDashboard;
