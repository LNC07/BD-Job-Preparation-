
import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { ref, onValue } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";
import { MCQ, ExamData } from '../types';
import { 
  Clock, CheckCircle2, XCircle, Trophy, RefreshCcw, 
  ArrowRight, ArrowLeft, Loader2, Sparkles, Frown, PartyPopper 
} from 'lucide-react';

interface ExamProps {
  onBack: () => void;
}

const Exam: React.FC<ExamProps> = ({ onBack }) => {
  const [examData, setExamData] = useState<ExamData | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [isFinished, setIsFinished] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    const examRef = ref(db, 'exam');
    return onValue(examRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        // Convert objects to array for questions if needed
        const questionsArray = data.questions ? Object.values(data.questions) as MCQ[] : [];
        setExamData({
          timeLimit: data.timeLimit || 20,
          questions: questionsArray // Removed slice(0, 20) to allow unlimited questions
        });
        setTimeLeft(data.timeLimit * 60);
      }
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    if (timeLeft > 0 && !isFinished && !loading) {
      const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && !isFinished && examData) {
      setIsFinished(true);
    }
  }, [timeLeft, isFinished, loading, examData]);

  const handleRetry = () => {
    if (!examData) return;
    setCurrentQuestionIndex(0);
    setAnswers({});
    setIsFinished(false);
    setTimeLeft(examData.timeLimit * 60);
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
        <p className="font-bold text-slate-500 uppercase tracking-widest">Loading Exam Hub...</p>
      </div>
    );
  }

  if (!examData || examData.questions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center space-y-6">
        <div className="bg-slate-100 p-8 rounded-[3rem]">
          <Clock className="w-20 h-20 text-slate-300 mx-auto" />
        </div>
        <div>
          <h2 className="text-3xl font-black text-slate-900">No Exams Scheduled</h2>
          <p className="text-slate-500 font-medium mt-2">Check back later for upcoming mock tests.</p>
        </div>
        <button onClick={onBack} className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center space-x-2">
          <ArrowLeft className="w-5 h-5" />
          <span>Go Back</span>
        </button>
      </div>
    );
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSelect = (optionIndex: number) => {
    if (isFinished) return;
    setAnswers({ ...answers, [examData.questions[currentQuestionIndex].id]: optionIndex });
  };

  const calculateResult = () => {
    let correct = 0;
    examData.questions.forEach(q => {
      if (answers[q.id] === q.correctAnswer) correct++;
    });
    return correct;
  };

  if (isFinished) {
    const score = calculateResult();
    const total = examData.questions.length;
    const percentage = (score / total) * 100;
    const isGood = percentage >= 60;

    return (
      <div className="max-w-2xl mx-auto px-6 py-20 animate-in fade-in zoom-in-95 duration-500">
        <div className={`p-12 rounded-[4rem] text-center shadow-2xl border ${isGood ? 'bg-emerald-50 border-emerald-100' : 'bg-rose-50 border-rose-100'}`}>
          <div className="inline-block p-8 rounded-[3rem] bg-white shadow-xl mb-8 relative">
            {isGood ? (
              <>
                <PartyPopper className="w-24 h-24 text-emerald-500" />
                <Sparkles className="absolute -top-4 -right-4 w-12 h-12 text-yellow-400 animate-pulse" />
              </>
            ) : (
              <Frown className="w-24 h-24 text-rose-500" />
            )}
          </div>
          
          <h2 className={`text-5xl font-black mb-4 ${isGood ? 'text-emerald-700' : 'text-rose-700'}`}>
            {isGood ? 'Brilliant Work!' : 'Keep Practicing!'}
          </h2>
          <p className="text-slate-500 font-bold text-xl mb-10">You scored {score} out of {total}</p>

          <div className="grid grid-cols-2 gap-6 mb-10">
            <div className="bg-white p-6 rounded-3xl shadow-sm">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Correct</p>
              <p className="text-3xl font-black text-emerald-600">{score}</p>
            </div>
            <div className="bg-white p-6 rounded-3xl shadow-sm">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Wrong</p>
              <p className="text-3xl font-black text-rose-600">{total - score}</p>
            </div>
          </div>

          <div className="flex flex-col space-y-4">
            <button 
              onClick={handleRetry}
              className="w-full bg-indigo-600 text-white py-5 rounded-3xl font-black text-lg flex items-center justify-center space-x-3 shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95"
            >
              <RefreshCcw className="w-5 h-5" />
              <span>Retry Exam</span>
            </button>
            <button 
              onClick={onBack}
              className="w-full py-5 bg-white text-slate-600 rounded-3xl font-black text-lg border border-slate-200 hover:bg-slate-50 transition-all"
            >
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentQ = examData.questions[currentQuestionIndex];

  return (
    <div className="max-w-4xl mx-auto px-6 py-10 pb-32">
      <header className="flex items-center justify-between mb-12">
        <div className="flex items-center space-x-4">
          <button onClick={onBack} className="p-4 bg-white rounded-2xl shadow-sm hover:bg-slate-50 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h2 className="text-2xl font-black text-slate-900">Live Mock Exam</h2>
            <div className="flex items-center space-x-2 text-indigo-600">
               <span className="text-[10px] font-black uppercase tracking-widest">Question {currentQuestionIndex + 1} of {examData.questions.length}</span>
            </div>
          </div>
        </div>

        <div className={`flex items-center space-x-3 px-6 py-4 rounded-3xl border ${timeLeft < 60 ? 'bg-rose-50 text-rose-600 border-rose-100 animate-pulse' : 'bg-indigo-50 text-indigo-600 border-indigo-100'}`}>
          <Clock className="w-6 h-6" />
          <span className="text-2xl font-black tabular-nums">{formatTime(timeLeft)}</span>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="w-full h-3 bg-slate-100 rounded-full mb-12 overflow-hidden">
        <div 
          className="h-full bg-indigo-600 transition-all duration-500"
          style={{ width: `${((currentQuestionIndex + 1) / examData.questions.length) * 100}%` }}
        ></div>
      </div>

      <div className="bg-white rounded-[3.5rem] p-10 md:p-16 shadow-2xl border border-slate-50 animate-in slide-in-from-bottom-8 duration-500">
        <h3 className="text-2xl md:text-3xl font-black text-slate-800 mb-12 leading-snug">
          {currentQ.question}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentQ.options.map((option, idx) => (
            <button
              key={idx}
              onClick={() => handleSelect(idx)}
              className={`p-6 rounded-[2rem] text-left border-2 transition-all group flex items-start space-x-4 ${
                answers[currentQ.id] === idx
                  ? 'bg-indigo-600 border-indigo-600 text-white'
                  : 'bg-slate-50 border-transparent hover:border-indigo-200 text-slate-600'
              }`}
            >
              <span className={`w-8 h-8 rounded-xl flex items-center justify-center font-black text-sm shrink-0 ${
                answers[currentQ.id] === idx ? 'bg-white/20' : 'bg-white text-indigo-600 shadow-sm'
              }`}>
                {String.fromCharCode(65 + idx)}
              </span>
              <span className="font-bold text-lg">{option}</span>
            </button>
          ))}
        </div>
      </div>

      <footer className="mt-12 flex items-center justify-between">
        <button 
          disabled={currentQuestionIndex === 0}
          onClick={() => setCurrentQuestionIndex(prev => prev - 1)}
          className="px-8 py-4 rounded-2xl font-bold text-slate-400 hover:text-slate-600 disabled:opacity-0 flex items-center space-x-2"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Previous</span>
        </button>

        {currentQuestionIndex === examData.questions.length - 1 ? (
          <button 
            onClick={() => setIsFinished(true)}
            className="px-10 py-5 bg-emerald-600 text-white rounded-[2rem] font-black text-xl shadow-xl shadow-emerald-100 hover:bg-emerald-700 transition-all flex items-center space-x-3"
          >
            <span>Finish Exam</span>
            <CheckCircle2 className="w-6 h-6" />
          </button>
        ) : (
          <button 
            onClick={() => setCurrentQuestionIndex(prev => prev + 1)}
            className="px-10 py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center space-x-3"
          >
            <span>Next Question</span>
            <ArrowRight className="w-6 h-6" />
          </button>
        )}
      </footer>
    </div>
  );
};

export default Exam;
