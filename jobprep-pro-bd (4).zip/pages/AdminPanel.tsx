
import React, { useState } from 'react';
import { Subject, JobCategory, Chapter } from '../types';
import { Plus, Trash2, Edit3, Save, X, FilePlus, ChevronDown, ChevronUp } from 'lucide-react';

interface AdminPanelProps {
  subjects: Subject[];
  jobs: JobCategory[];
  onAddChapter: (subjectId: string, chapter: Chapter) => void;
  onAddJob: (job: JobCategory) => void;
  onDeleteChapter: (subjectId: string, chapterId: string) => void;
  onDeleteJob: (jobId: string) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ 
  subjects, 
  jobs, 
  onAddChapter, 
  onAddJob, 
  onDeleteChapter, 
  onDeleteJob 
}) => {
  const [activeTab, setActiveTab] = useState<'SUBJECTS' | 'JOBS'>('SUBJECTS');
  const [expandedSubject, setExpandedSubject] = useState<string | null>(null);
  
  // Form states
  const [newChapterName, setNewChapterName] = useState('');
  const [newChapterPdf, setNewChapterPdf] = useState('');
  const [newJobName, setNewJobName] = useState('');
  const [newJobDesc, setNewJobDesc] = useState('');
  const [newJobPdf, setNewJobPdf] = useState('');
  // Added sector state to match JobCategory type requirements
  const [newJobSector, setNewJobSector] = useState<JobCategory['sector']>('Government');

  const handleAddChapter = (subjectId: string) => {
    if (!newChapterName || !newChapterPdf) return;
    const chapter: Chapter = {
      id: Math.random().toString(36).substr(2, 9),
      name: newChapterName,
      pdfUrl: newChapterPdf
    };
    onAddChapter(subjectId, chapter);
    setNewChapterName('');
    setNewChapterPdf('');
  };

  const handleAddJob = () => {
    if (!newJobName || !newJobPdf) return;
    // Added 'sector' property to resolve the missing property error
    // Fix: JobCategory interface requires 'chapters' array, not a top-level 'pdfUrl'
    const job: JobCategory = {
      id: Math.random().toString(36).substr(2, 9),
      name: newJobName,
      sector: newJobSector,
      description: newJobDesc,
      chapters: [
        {
          id: Math.random().toString(36).substr(2, 9),
          name: "Reference Document",
          pdfUrl: newJobPdf
        }
      ]
    };
    onAddJob(job);
    setNewJobName('');
    setNewJobDesc('');
    setNewJobPdf('');
    setNewJobSector('Government');
  };

  return (
    <div className="max-w-5xl mx-auto pb-20">
      <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="flex bg-slate-50 border-b border-slate-200">
          <button 
            onClick={() => setActiveTab('SUBJECTS')}
            className={`flex-1 px-6 py-4 font-bold text-sm uppercase tracking-wider transition-all ${
              activeTab === 'SUBJECTS' ? 'bg-white text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Manage Subjects
          </button>
          <button 
            onClick={() => setActiveTab('JOBS')}
            className={`flex-1 px-6 py-4 font-bold text-sm uppercase tracking-wider transition-all ${
              activeTab === 'JOBS' ? 'bg-white text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Manage Job Categories
          </button>
        </div>

        <div className="p-6 md:p-8">
          {activeTab === 'SUBJECTS' ? (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Subject & Chapter Control</h3>
              {subjects.map((subject) => (
                <div key={subject.id} className="border border-slate-100 rounded-2xl overflow-hidden">
                  <button 
                    onClick={() => setExpandedSubject(expandedSubject === subject.id ? null : subject.id)}
                    className="w-full flex items-center justify-between p-4 bg-slate-50/50 hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="bg-white p-2 rounded-lg text-indigo-600 shadow-sm border border-slate-100">
                        <Edit3 className="w-5 h-5" />
                      </div>
                      <span className="font-bold text-slate-700">{subject.name}</span>
                      <span className="bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded text-xs font-semibold">
                        {subject.chapters.length} Chapters
                      </span>
                    </div>
                    {expandedSubject === subject.id ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </button>

                  {expandedSubject === subject.id && (
                    <div className="p-4 bg-white space-y-4">
                      {/* Chapter List */}
                      <div className="space-y-2">
                        {subject.chapters.map((chapter) => (
                          <div key={chapter.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 text-sm">
                            <span className="font-medium text-slate-700">{chapter.name}</span>
                            <button 
                              onClick={() => onDeleteChapter(subject.id, chapter.id)}
                              className="text-red-400 hover:text-red-600 p-1 hover:bg-white rounded transition-all"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>

                      {/* Add New Chapter */}
                      <div className="pt-4 border-t border-slate-100 space-y-3">
                        <p className="text-xs font-bold text-slate-400 uppercase">Add New Chapter</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <input 
                            type="text" 
                            placeholder="Chapter Name" 
                            className="px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            value={newChapterName}
                            onChange={(e) => setNewChapterName(e.target.value)}
                          />
                          <input 
                            type="text" 
                            placeholder="PDF Link (URL)" 
                            className="px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            value={newChapterPdf}
                            onChange={(e) => setNewChapterPdf(e.target.value)}
                          />
                        </div>
                        <button 
                          onClick={() => handleAddChapter(subject.id)}
                          className="w-full flex items-center justify-center space-x-2 py-2 bg-indigo-600 text-white rounded-lg font-bold text-sm hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Add Chapter to {subject.name}</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-8">
              {/* Add New Job Form */}
              <div className="bg-indigo-50/50 p-6 rounded-3xl border border-indigo-100">
                <div className="flex items-center space-x-2 mb-6">
                  <div className="bg-indigo-600 p-2 rounded-lg text-white">
                    <FilePlus className="w-5 h-5" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800">New Job Category</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600">Job Title</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Primary School Teacher" 
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                      value={newJobName}
                      onChange={(e) => setNewJobName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600">PDF Document Link</label>
                    <input 
                      type="text" 
                      placeholder="https://example.com/file.pdf" 
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                      value={newJobPdf}
                      onChange={(e) => setNewJobPdf(e.target.value)}
                    />
                  </div>
                  {/* Added Sector Selection */}
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-600">Sector</label>
                    <select 
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
                      value={newJobSector}
                      onChange={(e) => setNewJobSector(e.target.value as any)}
                    >
                      <option value="Government">Government</option>
                      <option value="Bank">Bank</option>
                      <option value="NGO">NGO</option>
                      <option value="Teacher">Teacher</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div className="md:col-span-2 space-y-2">
                    <label className="text-sm font-bold text-slate-600">Description</label>
                    <textarea 
                      placeholder="Short summary of this job category..." 
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none h-24 resize-none"
                      value={newJobDesc}
                      onChange={(e) => setNewJobDesc(e.target.value)}
                    />
                  </div>
                </div>
                
                <button 
                  onClick={handleAddJob}
                  className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 flex items-center justify-center space-x-2"
                >
                  <Save className="w-5 h-5" />
                  <span>Save Job Category</span>
                </button>
              </div>

              {/* Jobs List */}
              <div className="space-y-4">
                <h4 className="text-lg font-bold text-slate-800">Current Job Categories</h4>
                <div className="grid grid-cols-1 gap-4">
                  {jobs.map((job) => (
                    <div key={job.id} className="flex items-center justify-between p-5 bg-white border border-slate-200 rounded-2xl shadow-sm">
                      <div className="flex-1">
                        <h5 className="font-bold text-slate-800">{job.name}</h5>
                        <p className="text-slate-500 text-xs line-clamp-1">{job.description}</p>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <button className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition-all">
                          <Edit3 className="w-5 h-5" />
                        </button>
                        <button 
                          onClick={() => onDeleteJob(job.id)}
                          className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
