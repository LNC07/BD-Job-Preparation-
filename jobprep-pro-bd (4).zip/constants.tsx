
import React from 'react';
import { 
  Book, Calculator, Globe, Languages, GraduationCap, 
  Briefcase, FileText, Landmark, ShieldCheck, HeartPulse, Building2, Crown, Gem, PlayCircle, Cpu, Monitor, FlaskConical, Map, Globe2, Scale, Train, SearchCode
} from 'lucide-react';
import { Subject, JobCategory, PremiumConfig } from './types';

// Add missing directAdLink property to comply with PremiumConfig interface
export const PREMIUM_CONFIG: PremiumConfig = {
  bkashNumber: "017XXXXXXXX",
  monthlyPrice: 150, // BDT
  directAdLink: "",
};

export const INITIAL_SUBJECTS: Subject[] = [
  {
    id: 'bangla',
    name: 'Bangla',
    icon: 'Book',
    chapters: []
  },
  {
    id: 'english',
    name: 'English',
    icon: 'Languages',
    chapters: []
  },
  {
    id: 'math',
    name: 'Mathematics',
    icon: 'Calculator',
    chapters: []
  },
  {
    id: 'ict',
    name: 'ICT',
    icon: 'Cpu',
    chapters: []
  },
  {
    id: 'science',
    name: 'Science',
    icon: 'FlaskConical',
    chapters: []
  },
  {
    id: 'bd_affairs',
    name: 'Bangladesh Affairs',
    icon: 'Map',
    chapters: []
  },
  {
    id: 'int_affairs',
    name: 'International Affairs',
    icon: 'Globe2',
    chapters: []
  },
  {
    id: 'geography',
    name: 'Geography',
    icon: 'Globe',
    chapters: []
  },
  {
    id: 'ethics',
    name: 'Ethics & Values',
    icon: 'Scale',
    chapters: []
  }
];

export const INITIAL_JOBS: JobCategory[] = [
  { id: 'j1', name: '47th BCS Preliminary', sector: 'Government', description: 'Complete 200-mark preparation kit for 47th BCS.', chapters: [] },
  { id: 'j2', name: 'Primary Teacher Recruitment', sector: 'Teacher', description: 'Essential guide for Government Primary School assistant teacher exam.', chapters: [] },
  { id: 'j3', name: 'Combined Bank Senior Officer', sector: 'Bank', description: 'Preparation for Sonali, Janata, Agrani & more.', chapters: [] },
  { id: 'j4', name: 'Railway Assistant Station Master', sector: 'Government', description: 'Railway department recruitment preparation notes.', chapters: [] },
  { id: 'j5', name: 'NSI Field Officer Prep', sector: 'Government', description: 'Exclusive syllabus and prep for National Security Intelligence.', chapters: [] },
  { id: 'j6', name: 'NGO Program Officer', sector: 'NGO', description: 'Career guide for BRAC, Grameen Bank and top NGOs.', chapters: [] }
];

export const getIcon = (name: string, className = "w-6 h-6") => {
  switch (name) {
    case 'Languages': return <Languages className={className} />;
    case 'Calculator': return <Calculator className={className} />;
    case 'Book': return <Book className={className} />;
    case 'Globe': return <Globe className={className} />;
    case 'Globe2': return <Globe2 className={className} />;
    case 'Cpu': return <Cpu className={className} />;
    case 'FlaskConical': return <FlaskConical className={className} />;
    case 'Map': return <Map className={className} />;
    case 'Scale': return <Scale className={className} />;
    case 'Monitor': return <Monitor className={className} />;
    case 'Train': return <Train className={className} />;
    case 'SearchCode': return <SearchCode className={className} />;
    case 'GraduationCap': return <GraduationCap className={className} />;
    case 'Briefcase': return <Briefcase className={className} />;
    case 'FileText': return <FileText className={className} />;
    case 'Landmark': return <Landmark className={className} />;
    case 'ShieldCheck': return <ShieldCheck className={className} />;
    case 'HeartPulse': return <HeartPulse className={className} />;
    case 'Building2': return <Building2 className={className} />;
    case 'Crown': return <Crown className={className} />;
    case 'Gem': return <Gem className={className} />;
    case 'PlayCircle': return <PlayCircle className={className} />;
    default: return <Book className={className} />;
  }
};