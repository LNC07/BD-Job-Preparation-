
export interface Chapter {
  id: string;
  name: string;
  pdfUrl: string;
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  chapters: Chapter[];
}

export interface JobCategory {
  id: string;
  name: string;
  sector: 'Government' | 'Bank' | 'NGO' | 'Teacher' | 'Other';
  description: string;
  chapters: Chapter[];
}

export interface MCQ {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number; // Index 0-3
}

export interface ExamData {
  timeLimit: number; // in minutes
  questions: MCQ[];
}

export interface SubscriptionPackage {
  id: string;
  name: string;
  price: number;
  days: number;
}

export interface PendingTransaction {
  id: string;
  txId: string;
  userId: string;
  userEmail: string;
  timestamp: number;
  status: 'pending' | 'approved' | 'rejected';
  packageName?: string;
  durationDays?: number;
}

export type AppView = 'HOME' | 'SUBJECT_DETAILS' | 'JOB_DETAILS' | 'JOB_SECTORS' | 'PDF_VIEWER' | 'AUTH' | 'EXAM';

export interface UserProfile {
  uid: string;
  email: string;
  isPremium: boolean;
  premiumExpiry: number | null;
}

export interface AppState {
  currentView: AppView;
  user: UserProfile | null;
  selectedSubject?: Subject;
  selectedJob?: JobCategory;
  selectedPdfUrl?: string;
  selectedPdfTitle?: string;
  tempAccessExpiry: number | null;
  pendingTxId: string | null;
}

export interface PremiumConfig {
  bkashNumber: string;
  monthlyPrice: number;
  adminPassword?: string;
  // Simplified Direct Link System
  directAdLink: string;
}
